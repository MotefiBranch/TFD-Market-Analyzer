// popup.js
// This script runs in the popup window. When the user clicks the
// "Open in Market Helper" button it parses the currently active
// market page, stores the parsed data in chrome.storage and opens
// a helper page to explore and filter the results.

// Track whether the helper has already been opened. This prevents duplicate
// parsing/opening when the user stops the capture before it finishes.
let openedHelper = false;
// Flag to indicate that a stop was requested. When true, auto‑scroll will
// continue in the tab but we won't open another helper once parsing finishes.
let stopRequested = false;

// Encapsulate the logic for parsing the page and opening the helper into a separate function
async function runMarketHelper() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) {
      alert('No active tab found.');
      return;
    }
    // Inject a parsing function into the active tab and return the results. The injected
    // function is asynchronous so that it can auto‑scroll the page before parsing
    // modules.
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: async () => {
        // Reset stop flag at the start of each capture. This ensures a fresh auto‑scroll run.
        window.__mhStopAutoScrollFlag = false;
        // Auto‑scroll to the bottom of the page to load all results. The page shows
        // a spinner/loader when additional results are being fetched. We scroll
        // repeatedly until the number of items stops increasing for a few cycles
        // AND any visible loader element disappears.
        async function autoScroll() {
          const loaderSelector = '[class*=\"loader\"], [class*=\"loading\"], [class*=\"spinner\"]';
          return new Promise(resolve => {
            let lastItemCount = 0;
            let stableCount = 0;
            const interval = setInterval(() => {
              // Check the stop flag each interval; if set, abort scrolling early
              if (window.__mhStopAutoScrollFlag) {
                clearInterval(interval);
                resolve();
                return;
              }
              const items = document.querySelectorAll('.items .item');
              const currentCount = items.length;
              // Scroll down to trigger lazy loading
              window.scrollTo(0, document.body.scrollHeight);
              // Determine whether a loader/spinner is visible
              const loaderEl = document.querySelector(loaderSelector);
              const loaderVisible = loaderEl && loaderEl.offsetParent !== null;
              if (currentCount === lastItemCount) {
                stableCount++;
              } else {
                stableCount = 0;
                lastItemCount = currentCount;
              }
              // If there are no new items for several cycles and no loader is visible, finish
              if (stableCount >= 3 && !loaderVisible) {
                clearInterval(interval);
                resolve();
              }
            }, 700);
          });
        }
        function parseModules() {
          // Support parsing both ancestor and trigger modules by delegating to
          // specialized helper functions. Each helper returns a module object
          // containing a common set of fields used by the helper UI. Ancestor
          // modules include socket type and required rank, whereas trigger
          // modules omit those fields and treat all stats as neutral.

          function parseAncestor(item) {
            const getText = (selector) => {
              const el = item.querySelector(selector);
              return el ? el.textContent.trim() : '';
            };
            const name = getText('.row-wrapper .name') || getText('.module-name');
            const category = getText('.row-wrapper .type');
            // Socket type can be found either in ancestor-info or item__info
            let socketType = '';
            const socketInfo = item.querySelector('.ancestor-info .socket-type');
            if (socketInfo) {
              socketType = socketInfo.textContent.trim();
            } else {
              const socketInfo2 = item.querySelector('.item__info .socket-type');
              if (socketInfo2) socketType = socketInfo2.textContent.trim();
            }
            const requiredRank = getText('.ancestor-info .required-rank span');
            const platform = getText('.seller .platform');
            const rerollCount = getText('.seller .reroll span');
            // Seller name and status
            let sellerName = '';
            let sellerStatus = '';
            const nickEl = item.querySelector('.seller .nickname');
            if (nickEl) {
              if (nickEl.childNodes && nickEl.childNodes.length > 0) {
                const firstNode = nickEl.childNodes[0];
                if (firstNode.nodeType === Node.TEXT_NODE) {
                  sellerName = firstNode.textContent.trim();
                } else {
                  sellerName = nickEl.textContent.trim();
                }
              }
              const stateEl = nickEl.querySelector('i');
              if (stateEl) {
                sellerStatus = stateEl.textContent.trim();
              }
            }
            const sellerRank = getText('.seller .rank span');
            const priceEl = item.querySelector('.price');
            let price = '';
            if (priceEl) {
              // The price node contains text nodes and a span for the currency
              price = Array.from(priceEl.childNodes)
                .filter(n => n.nodeType === Node.TEXT_NODE)
                .map(n => n.textContent.trim())
                .join(' ');
            }
            const attributes = [];
            const stats = [];
            // Parse each option to extract label (with range) and value separately
            const optionEls = item.querySelectorAll('.item__details .option');
            optionEls.forEach(opt => {
              const nameEl = opt.querySelector('.option-name');
              const valueEl = opt.querySelector('.option-value');
              if (!nameEl) return;
              const labelRaw = nameEl.textContent.trim();
              // Determine sign for colouring
              const positive = labelRaw.startsWith('(+)');
              const negative = labelRaw.startsWith('(-)');
              // Extract attribute name (remove sign and range)
              let attrName = labelRaw.replace(/^\(\+\)|^\(\-\)/, '').split('[')[0].trim();
              if (attrName && !attributes.includes(attrName)) {
                attributes.push(attrName);
              }
              const valueText = valueEl ? valueEl.textContent.trim() : '';
              stats.push({ raw: labelRaw, positive, negative, value: valueText });
            });
            const regDate = getText('.information .date span');
            return {
              name,
              category,
              socketType,
              requiredRank,
              price,
              platform,
              rerollCount,
              sellerName,
              sellerStatus,
              sellerRank,
              regDate,
              attributes,
              stats
            };
          }

          function parseTrigger(item) {
            const getText = (selector) => {
              const el = item.querySelector(selector);
              return el ? el.textContent.trim() : '';
            };
            const name = getText('.row-wrapper .name') || getText('.module-name');
            const category = getText('.row-wrapper .type');
            // Trigger modules do not include a socket type in the UI
            const socketType = '';
            // Attempt to extract a required mastery rank if available; many trigger
            // listings omit this field. We look for elements commonly used on
            // ancestor items and fall back to an empty string.
            let requiredRank = '';
            const reqSpan = item.querySelector('.item__info .required-mastery-rank span, .item__info .required-rank span');
            if (reqSpan && reqSpan.textContent) {
              requiredRank = reqSpan.textContent.trim();
            }
            const platform = getText('.seller .platform');
            const rerollCount = getText('.seller .reroll span');
            let sellerName = '';
            let sellerStatus = '';
            const nickEl = item.querySelector('.seller .nickname');
            if (nickEl) {
              if (nickEl.childNodes && nickEl.childNodes.length > 0) {
                const firstNode = nickEl.childNodes[0];
                if (firstNode.nodeType === Node.TEXT_NODE) {
                  sellerName = firstNode.textContent.trim();
                } else {
                  sellerName = nickEl.textContent.trim();
                }
              }
              const stateEl = nickEl.querySelector('i');
              if (stateEl) {
                sellerStatus = stateEl.textContent.trim();
              }
            }
            const sellerRank = getText('.seller .rank span');
            const priceEl = item.querySelector('.price');
            let price = '';
            if (priceEl) {
              price = Array.from(priceEl.childNodes)
                .filter(n => n.nodeType === Node.TEXT_NODE)
                .map(n => n.textContent.trim())
                .join(' ');
            }
            const attributes = [];
            const stats = [];
            const optionEls = item.querySelectorAll('.item__details .option');
            optionEls.forEach(opt => {
              const nameEl = opt.querySelector('.option-name');
              const valueEl = opt.querySelector('.option-value');
              const labelText = nameEl ? nameEl.textContent.trim() : '';
              const valueText = valueEl ? valueEl.textContent.trim() : '';
              // Extract attribute name for filtering by removing the range in parentheses
              let attrName = labelText.split('(')[0].trim();
              if (attrName && !attributes.includes(attrName)) {
                attributes.push(attrName);
              }
              const raw = labelText + ' ' + valueText;
              // Trigger stats are neutral (no positive/negative colours)
              stats.push({ raw, positive: false, negative: false, value: valueText });
            });
            const regDate = getText('.information .date span');
            return {
              name,
              category,
              socketType,
              requiredRank,
              price,
              platform,
              rerollCount,
              sellerName,
              sellerStatus,
              sellerRank,
              regDate,
              attributes,
              stats
            };
          }

          const modules = [];
          const itemNodes = document.querySelectorAll('.items .item');
          itemNodes.forEach(item => {
            // Determine module type from category; triggers contain the word 'trigger'
            const typeEl = item.querySelector('.row-wrapper .type');
            const category = typeEl ? typeEl.textContent.trim() : '';
            const isTrigger = category.toLowerCase().includes('trigger');
            const mod = isTrigger ? parseTrigger(item) : parseAncestor(item);
            modules.push(mod);
          });
          return modules;
        }
        try {
          // Wait until all items have been loaded via auto‑scroll
          await autoScroll();
          return parseModules();
        } catch (err) {
          return { error: err.toString() };
        }
      }
    });
    if (result && result.error) {
      alert('Error parsing page: ' + result.error);
      return;
    }
    // If the helper has already been opened via a stop request, don't open it again
    if (!openedHelper) {
      openedHelper = true;
      // Save the parsed modules to chrome.storage
      await chrome.storage.local.set({ marketData: result });
      // Open the helper page in a new tab
      const url = chrome.runtime.getURL('market_helper.html');
      chrome.tabs.create({ url });
      // Close the popup window after launching the helper
      window.close();
    }
  } catch (err) {
    console.error(err);
    alert('Failed to run Market Helper: ' + err.message);
  }
}

// Parse the currently visible items without further scrolling and open the helper
async function parseNowAndOpen() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;
    // Inject a script to parse whatever modules are currently visible on the page
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        function parseModules() {
          function parseAncestor(item) {
            const getText = (selector) => {
              const el = item.querySelector(selector);
              return el ? el.textContent.trim() : '';
            };
            const name = getText('.row-wrapper .name') || getText('.module-name');
            const category = getText('.row-wrapper .type');
            let socketType = '';
            const socketInfo = item.querySelector('.ancestor-info .socket-type');
            if (socketInfo) {
              socketType = socketInfo.textContent.trim();
            } else {
              const socketInfo2 = item.querySelector('.item__info .socket-type');
              if (socketInfo2) socketType = socketInfo2.textContent.trim();
            }
            const requiredRank = getText('.ancestor-info .required-rank span');
            const platform = getText('.seller .platform');
            const rerollCount = getText('.seller .reroll span');
            let sellerName = '';
            let sellerStatus = '';
            const nickEl = item.querySelector('.seller .nickname');
            if (nickEl) {
              if (nickEl.childNodes && nickEl.childNodes.length > 0) {
                const firstNode = nickEl.childNodes[0];
                if (firstNode.nodeType === Node.TEXT_NODE) {
                  sellerName = firstNode.textContent.trim();
                } else {
                  sellerName = nickEl.textContent.trim();
                }
              }
              const stateEl = nickEl.querySelector('i');
              if (stateEl) {
                sellerStatus = stateEl.textContent.trim();
              }
            }
            const sellerRank = getText('.seller .rank span');
            const priceEl = item.querySelector('.price');
            let price = '';
            if (priceEl) {
              price = Array.from(priceEl.childNodes)
                .filter(n => n.nodeType === Node.TEXT_NODE)
                .map(n => n.textContent.trim())
                .join(' ');
            }
            const attributes = [];
            const stats = [];
            // Use option elements to capture both label (with range) and value
            const optionEls = item.querySelectorAll('.item__details .option');
            optionEls.forEach(opt => {
              const nameEl = opt.querySelector('.option-name');
              const valueEl = opt.querySelector('.option-value');
              if (!nameEl) return;
              const labelRaw = nameEl.textContent.trim();
              const positive = labelRaw.startsWith('(+)');
              const negative = labelRaw.startsWith('(-)');
              let attrName = labelRaw.replace(/^\(\+\)|^\(\-\)/, '').split('[')[0].trim();
              if (attrName && !attributes.includes(attrName)) {
                attributes.push(attrName);
              }
              const valueText = valueEl ? valueEl.textContent.trim() : '';
              stats.push({ raw: labelRaw, positive, negative, value: valueText });
            });
            const regDate = getText('.information .date span');
            return {
              name,
              category,
              socketType,
              requiredRank,
              price,
              platform,
              rerollCount,
              sellerName,
              sellerStatus,
              sellerRank,
              regDate,
              attributes,
              stats
            };
          }
          function parseTrigger(item) {
            const getText = (selector) => {
              const el = item.querySelector(selector);
              return el ? el.textContent.trim() : '';
            };
            const name = getText('.row-wrapper .name') || getText('.module-name');
            const category = getText('.row-wrapper .type');
            const socketType = '';
            let requiredRank = '';
            const reqSpan = item.querySelector('.item__info .required-mastery-rank span, .item__info .required-rank span');
            if (reqSpan && reqSpan.textContent) {
              requiredRank = reqSpan.textContent.trim();
            }
            const platform = getText('.seller .platform');
            const rerollCount = getText('.seller .reroll span');
            let sellerName = '';
            let sellerStatus = '';
            const nickEl = item.querySelector('.seller .nickname');
            if (nickEl) {
              if (nickEl.childNodes && nickEl.childNodes.length > 0) {
                const firstNode = nickEl.childNodes[0];
                if (firstNode.nodeType === Node.TEXT_NODE) {
                  sellerName = firstNode.textContent.trim();
                } else {
                  sellerName = nickEl.textContent.trim();
                }
              }
              const stateEl = nickEl.querySelector('i');
              if (stateEl) {
                sellerStatus = stateEl.textContent.trim();
              }
            }
            const sellerRank = getText('.seller .rank span');
            const priceEl = item.querySelector('.price');
            let price = '';
            if (priceEl) {
              price = Array.from(priceEl.childNodes)
                .filter(n => n.nodeType === Node.TEXT_NODE)
                .map(n => n.textContent.trim())
                .join(' ');
            }
            const attributes = [];
            const stats = [];
            const optionEls = item.querySelectorAll('.item__details .option');
            optionEls.forEach(opt => {
              const nameEl = opt.querySelector('.option-name');
              const valueEl = opt.querySelector('.option-value');
              const labelText = nameEl ? nameEl.textContent.trim() : '';
              const valueText = valueEl ? valueEl.textContent.trim() : '';
              let attrName = labelText.split('(')[0].trim();
              if (attrName && !attributes.includes(attrName)) {
                attributes.push(attrName);
              }
              const raw = labelText + ' ' + valueText;
              stats.push({ raw, positive: false, negative: false, value: valueText });
            });
            const regDate = getText('.information .date span');
            return {
              name,
              category,
              socketType,
              requiredRank,
              price,
              platform,
              rerollCount,
              sellerName,
              sellerStatus,
              sellerRank,
              regDate,
              attributes,
              stats
            };
          }
          const modules = [];
          const itemNodes = document.querySelectorAll('.items .item');
          itemNodes.forEach(item => {
            const typeEl = item.querySelector('.row-wrapper .type');
            const category = typeEl ? typeEl.textContent.trim() : '';
            const isTrigger = category.toLowerCase().includes('trigger');
            const mod = isTrigger ? parseTrigger(item) : parseAncestor(item);
            modules.push(mod);
          });
          return modules;
        }
        try {
          return parseModules();
        } catch (err) {
          return { error: err.toString() };
        }
      }
    });
    if (result && result.error) {
      alert('Error parsing page: ' + result.error);
      return;
    }
    if (!openedHelper) {
      openedHelper = true;
      await chrome.storage.local.set({ marketData: result });
      const url = chrome.runtime.getURL('market_helper.html');
      chrome.tabs.create({ url });
      window.close();
    }
  } catch (err) {
    console.error(err);
    alert('Failed to parse current data: ' + err.message);
  }
}

// Show confirmation container when the button is clicked
const openBtn = document.getElementById('open-helper');
const confirmContainer = document.getElementById('confirm-container');
const proceedBtn = document.getElementById('confirm-proceed');
const cancelBtn = document.getElementById('confirm-cancel');
const stopBtn = document.getElementById('stop-capture');
const abortBtn = document.getElementById('abort-capture');

openBtn.addEventListener('click', () => {
  if (confirmContainer) {
    // Hide open button and show confirmation container
    openBtn.style.display = 'none';
    confirmContainer.classList.remove('hidden');
  } else {
    // Fallback: directly run the helper if confirmation container not found
    runMarketHelper();
  }
});

// When user proceeds, run the helper and close popup
if (proceedBtn) {
  proceedBtn.addEventListener('click', () => {
    // Hide confirmation box and show a loading message while the auto‑scroll runs
    if (confirmContainer) confirmContainer.classList.add('hidden');
    // Hide the open helper button
    openBtn.style.display = 'none';
    const loadingCont = document.getElementById('loading-container');
    if (loadingCont) loadingCont.classList.remove('hidden');
    runMarketHelper();
  });
}

// When user cancels, hide confirmation and show open button again
if (cancelBtn) {
  cancelBtn.addEventListener('click', () => {
    if (confirmContainer) confirmContainer.classList.add('hidden');
    // Show the open helper button again
    openBtn.style.display = 'block';
  });
}

// When user clicks stop during capture, parse current data and open helper
if (stopBtn) {
  stopBtn.addEventListener('click', async () => {
    // Indicate that a stop is requested
    stopRequested = true;
    try {
      // Set the stop flag in page context to interrupt auto-scroll
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab) {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            window.__mhStopAutoScrollFlag = true;
          }
        });
      }
    } catch (err) {
      console.error('Error setting stop flag:', err);
    }
    // Hide loading container to prevent confusion while parsing
    const loadingCont = document.getElementById('loading-container');
    if (loadingCont) loadingCont.classList.add('hidden');
    // Parse currently loaded items and open helper
    parseNowAndOpen();
  });
}

// Abort button: cancel the capture and return to initial state without parsing
if (abortBtn) {
  abortBtn.addEventListener('click', async () => {
    // Indicate that stop is requested and prevent any further helper opening
    stopRequested = true;
    openedHelper = true;
    try {
      // Set the stop flag in page context to interrupt auto-scroll
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab) {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            window.__mhStopAutoScrollFlag = true;
          }
        });
      }
    } catch (err) {
      console.error('Error setting abort flag:', err);
    }
    // Hide loading container and show the open-helper button
    const loadingCont = document.getElementById('loading-container');
    if (loadingCont) loadingCont.classList.add('hidden');
    // Show the open helper button again to allow starting over
    openBtn.style.display = 'block';
  });
}